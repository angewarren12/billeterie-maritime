<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Billet Maritime Express</title>
    <style>
        body { font-family: sans-serif; color: #333; margin: 0; padding: 0; }
        .page-break { page-break-after: always; }
        .header { background-color: #22c55e; color: white; padding: 20px; text-align: center; }
        .logo { font-size: 24px; font-weight: bold; text-transform: uppercase; }
        .content { padding: 30px; }
        .route-info { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #eee; padding-bottom: 20px; }
        .route-name { font-size: 24px; font-weight: bold; color: #16a34a; }
        .trip-date { font-size: 16px; color: #666; margin-top: 5px; }
        .passenger-card { border: 1px solid #ddd; border-radius: 8px; padding: 20px; margin-bottom: 20px; position: relative; }
        .qr-code { position: absolute; top: 20px; right: 20px; width: 120px; height: 120px; }
        .label { font-size: 12px; text-transform: uppercase; color: #888; margin-bottom: 4px; }
        .value { font-size: 16px; font-weight: bold; margin-bottom: 15px; }
        .footer { position: fixed; bottom: 0; left: 0; right: 0; text-align: center; font-size: 10px; color: #999; padding: 10px; border-top: 1px solid #eee; }
        .status-badge { display: inline-block; padding: 4px 8px; border-radius: 4px; background: #e5e7eb; font-size: 12px; }
        .status-valid { background: #dcfce7; color: #166534; }
    </style>
</head>
<body>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $ticket = $data['model']; $trip = $ticket->trip; ?>
        
        <div class="header">
            <div class="logo">Maritime Express</div>
            <div>Billet Électronique</div>
        </div>

        <div class="content">
            <div class="route-info">
                <div class="route-name">
                    <?php echo e($trip->route->departurePort->name); ?> ➔ <?php echo e($trip->route->arrivalPort->name); ?>

                </div>
                <div class="trip-date">
                    Départ : <?php echo e(\Carbon\Carbon::parse($trip->departure_time)->format('d/m/Y à H:i')); ?>

                    <br>
                    Navire : <?php echo e($trip->ship->name); ?>

                </div>
            </div>

            <div class="passenger-card">
                <div class="qr-code">
                    <img src="<?php echo e($data['qr_code']); ?>" style="width: 100%; height: auto;">
                </div>

                <div style="width: 70%;">
                    <div class="label">Passager</div>
                    <div class="value"><?php echo e($ticket->passenger_name); ?></div>

                    <div style="display: flex; gap: 40px;">
                        <div>
                            <div class="label">Type</div>
                            <div class="value">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ticket->passenger_type == 'child'): ?> Enfant
                                <?php elseif($ticket->passenger_type == 'baby'): ?> Bébé
                                <?php else: ?> Adulte
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <div class="label">Nationalité</div>
                            <div class="value">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ticket->nationality_group == 'national'): ?> National / CEDEAO
                                <?php elseif($ticket->nationality_group == 'resident'): ?> Résident
                                <?php else: ?> Étranger
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div style="display: flex; gap: 40px;">
                        <div>
                            <div class="label">Référence Réservation</div>
                            <div class="value"><?php echo e($booking->booking_reference); ?></div>
                        </div>
                        <div>
                            <div class="label">N° Billet</div>
                            <div class="value">#<?php echo e($ticket->id); ?></div>
                        </div>
                    </div>
                
                    <div class="label">Prix Payé</div>
                    <div class="value"><?php echo e(number_format($ticket->price_paid, 0, ',', ' ')); ?> FCFA</div>
                </div>
            </div>

            <div style="margin-top: 30px; font-size: 14px; line-height: 1.6; color: #555;">
                <strong>Instructions d'embarquement :</strong>
                <ul>
                    <li>Présentez-vous au port 30 minutes avant le départ.</li>
                    <li>Munissez-vous d'une pièce d'identité valide correspondant au billet.</li>
                    <li>Ce code QR sera scanné à l'entrée du terminal.</li>
                </ul>
            </div>
        </div>

        <div class="footer">
            Page <?php echo e($index + 1); ?> / <?php echo e(count($tickets)); ?> • Émis le <?php echo e(now()->format('d/m/Y H:i')); ?> • Maritime Express Inc.
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$loop->last): ?>
            <div class="page-break"></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\ThinkPad\.gemini\antigravity\scratch\billetterie-maritime\backend\resources\views/pdf/ticket.blade.php ENDPATH**/ ?>